import os 
import numpy as np 
from PIL import Image, ImageFilter, ImageEnhance, ImageOps
import cv2

path = "camera_resized_ud/"
os.makedirs("new_data", exist_ok=True)

# Try CLAHE

for k, f in enumerate(sorted([int(x.split(".")[0]) for x in os.listdir(path)])):
    img = np.array(Image.open(path+str(f)+".png"))

    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    lab = cv2.cvtColor(img, cv2.COLOR_RGB2LAB)
    l, a, b = cv2.split(lab)
    cl = clahe.apply(l)
    limg = cv2.merge((cl, a, b))

    img = cv2.cvtColor(limg, cv2.COLOR_LAB2RGB)

    Image.fromarray(np.uint8(img)).save("camera_resized/%d.png" % (k+1))