from PIL import Image
import os, sys 
from custom_functions \
import create_data_as_list, format_unix_to_utc, extract_data_with_angles, create_matching_pair, resize_image_in_folder, rename_files_in_folder
import argparse

if __name__ == '__main__':

    parser = argparse.ArgumentParser()
    parser.add_argument("--img_width", type=int, default=64, help="width of the image")
    parser.add_argument("--img_height", type=int, default=64, help="width of the image")
    parser.add_argument("--distorted", type=bool, default=True, help="Set False if you want undistorted image")
    
    opt = parser.parse_args()

    pixel_image_source_path = "PATH\\TO\\scan_intensity_image"
    pixel_output_path = "C:\\PATH\\TO\\SAVE"

    frame_image_source_path = "C:\\PATH\\TO\\undistorted_frames\\" if opt.distorted == False else \
        "C:\\PATH\\TO\\frames\\"
    frame_image_output_path = "C:\\PATH\\TO\\SAVE"


    size = opt.img_width, opt.img_height
    resize_image_in_folder(pixel_image_source_path, pixel_output_path, size)
    filename_pair = create_matching_pair(opt.distorted)

    for f in os.listdir(frame_image_source_path):
        for f_name in filename_pair:
            if f == f_name["frame"]:
                try:
                    img = Image.open(frame_image_source_path + f)
                    img = img.resize(size, Image.ANTIALIAS)
                    img.save((frame_image_output_path+f))
                except IOError:
                    print("Error resizing image")

    # Rename the files in the gan data folders 
    rename_files_in_folder(frame_image_output_path)
    rename_files_in_folder(pixel_output_path)

    print("Task Finished")
    # 
    # To keep aspect ratio:
    # basewidth = 100
    # wpercent = (basewidth / float(img.size[0]))
    # hsize = int((float(img.size[1]) * float(wpercent)))
