import datetime
import time
import math
import os
from PIL import Image

def create_data_as_list(file_name, identifier=",", distorted=True):
	# Returns an array of items 
	# Items are in dictionary with the header as key, and the actual value as the value
	#
	# Param: 
	#	file_name - file name to extract the data from
	#	identifier - identifier that separates each criteria
	if identifier == "t":
		identifier = "\t"
	
	content = []
	
	# Read the file and detatch unnecessary symbols
	with open(file_name, 'r') as f:
		for line in f.readlines():
			lines = []

			# if we want the undistorted data
			if distorted == False:
				try:
					line = line.replace("frame_", "frame_ud_")
				except:
					continue

			for item in line.split(identifier):
				if '\n' in item:
					item = item.replace('\n', '')
					lines.append(item)
					content.append(lines)
				else:
					lines.append(item)
	
	# Create the list of items from the modified content
	list_of_items = []

	for i in range(1, len(content)):
		item = {}
		for j in range(len(content[0])):
			item[('%s' % str(content[0][j]))] = content[i][j]
		list_of_items.append(item)
	
	return list_of_items

def extract_data_with_angles(a_from=0.0, a_to=360.0, given_data=[]):
	# Returns an array of dict item that gives the data
	# with the values of the given start angle (a_from) to last angle(a_to) 
	# within the given dataset (given_data)

	scan_data = []
	for data in given_data:
		degree = (float(data["field.angle_rad"]) * (180.0/math.pi))
		if degree > a_from and degree < a_to:
			data["%time"] = str(data["%time"]).split(" ")[1]
			data["field.angle_rad"] = degree
			scan_data.append(data)
	
	return scan_data

def format_unix_to_utc(dataset):
	# Format the unix epoch time to utc from the sonarseaking data
	for data in dataset:
		dt = datetime.datetime.utcfromtimestamp(int(data["%time"]) // 1000000000)
		s = dt.strftime('%Y-%m-%d %H:%M:%S')
		s += '.' + str(int(int(data["%time"]) % 1000000000)).zfill(9)
		data["%time"] = s
	
	return dataset

def calculate_number_of_angles(data):
	# Calculates the number of angles in the configured data
	#
	#

	stack = []
	for x in data:
		if(x["field.angle_rad"] not in stack):
			stack.append(x["field.angle_rad"])
	return len(stack)

def create_matching_pair(distorted):
	# Creates an array of dictionary with the image file name of (laser scan, camera frame) for sonar seaking (vertical)
	#

    # Load the raw data
    _sonar_raw = r"C:\PATH\TO\sonar_seaking.txt"
    sonar_seaking_data = create_data_as_list(_sonar_raw)

    # Format the unix timestamps to utc
    sonar_seaking_data = format_unix_to_utc(sonar_seaking_data)

    # Extract data
    camera_info = create_data_as_list(r"C:\PATH\TO\camera_timestamp.txt", 't', distorted=distorted)

    # Create a matching pair of frame image for each scan data
    scan_timestamps = []
    frame_timestamps = []
    for f in os.listdir("C:\\PATH\\TO\\GAN_data\\resized_images\\"):
        temp = f.replace("_", "")
        temp = temp.split(".png")[0]
        scan_timestamps.append(temp)

    for t in camera_info:
        temp = t["utc"].split("#")[1].replace(":", "")
        frame_timestamps.append(temp)

    pair_timestamps = []

    # Create a pair of (scan, frame) timestamps
    for s in scan_timestamps:
        pairs = {}
        for f in frame_timestamps:
            # Check if seconds match
            if s.split(".")[0] == f.split(".")[0]:
                # find min micro seconds
                micro_min = float("0." + s.split(".")[1]) - float("0." + f.split(".")[1])
                if micro_min > -0.2 and micro_min < 0.2:
                    # reformat the time string
                    scan_s = s.split(".")[0]
                    temp_scan = '_'.join(a+b for a,b in zip(scan_s[::2], scan_s[1::2]))
                    frame_s = f.split(".")[0]
                    temp_frame = ':'.join(a+b for a,b in zip(frame_s[::2], frame_s[1::2]))

                    pairs["scan"] = temp_scan + "." + s.split(".")[1] 
                    pairs["frame"] = "#" + temp_frame + "." + f.split(".")[1]
                    if pairs not in pair_timestamps:
                        pair_timestamps.append(pairs)

    # extract the frame name with the frame timestamps in the pair timestamps list
    for x in pair_timestamps:
        for c in camera_info:
            if x["frame"] == c["utc"]:
                x["frame"] = c["file_num"]
                x["scan"] = x["scan"] + ".png"

    return pair_timestamps

def resize_image_in_folder(source_dir, output_dir, size=(100, 100)): 
	# Resizes the image in folder with the given size
	for f in os.listdir(source_dir):
		if ".png" in f:
			try: 
				img = Image.open(source_dir + f)
				img = img.resize(size, Image.ANTIALIAS)
				img.save((output_dir+f))
			except IOError:
				print("Error resizing image")

def rename_files_in_folder(directory):
	# Renames the files in the folder with numbers
	i = 1
	for f in os.listdir(directory):
		os.rename((directory+f), (directory+str(i)+".png"))
		i+=1