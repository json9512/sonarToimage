from custom_functions import create_data_as_list, extract_data_with_angles, format_unix_to_utc,calculate_number_of_angles, resize_image_in_folder
import math 
import datetime
from PIL import Image, ImageDraw
import matplotlib.pyplot as plt
import argparse

if __name__ == "__main__":
	parser = argparse.ArgumentParser()
	parser.add_argument("--angle_min", type=float, default=167.0, help="Set the minimum angle for capture")
	parser.add_argument("--angle_max", type=float, default=195.0, help="Set the maximum angle for capture")
	parser.add_argument("--scan_only", type=bool, default=False, help="Set True to resize scan data by 64x64")
	opt = parser.parse_args()

	# Load the raw data
	_sonar_raw = r"C:\PATH\TO\sonar_seaking.txt"
	sonar_seaking_data = create_data_as_list(_sonar_raw)

	# Format the unix timestamps to utc
	sonar_seaking_data = format_unix_to_utc(sonar_seaking_data)

	# Extract data with only the angles of 167 and 195 (+ 15 degrees - 15 degrees from 180deg)
	scan_data = extract_data_with_angles(opt.angle_min, opt.angle_max, sonar_seaking_data)
	number_of_angles = calculate_number_of_angles(scan_data)

	# Configure the x,y values for the data 
	# There are n scans (col)
	# with 50 beams(intensity) values (row)
	configed_data = []

	for data in scan_data:
		temp = {}
		x = []
		y = []
		# Store all the x and y points
		for i in range(50):
			x.append(i)
			y.append(float(data["field.beam_data{0}".format(i)]))
		
		# Create the dict and store all the values
		temp["time"] = data["%time"]
		temp["angle"] = data["field.angle_rad"]
		temp["x"] = x
		temp["y"] = y
		configed_data.append(temp)

	# Set the image parameters
	width = number_of_angles # Number of angles 
	column = 176 # max intensity value (175) + 1 
	mode = 'RGB'
	size= (width,column)
	color = (0, 0, 0)

	image_output_path = "C:\\PATH\\TO\\SAVE"

	# Create empty image
	im = Image.new(mode, size, color)

	all_x = []
	all_y = []
	x_count = 0 # [There are 16 angles, so 0 - 15]

	# This loop will try to create an image for all the scans that are captured in one second
	# col: 16(number of angles in one second scan with an angle increment of 2)
	# row: 176(max intensity)
	# 
	# Iterate data item
	for j, d in enumerate(configed_data):
		# Load the pixels 
		pixels = im.load()

		# Iterate each x and y points 
		for i in range(50):
			# change the color of each pixel 
			pixels[x_count, d["y"][i]] = (255, 255, 255)

			# Test purpose
			all_x.append(x_count)
			all_y.append(d['y'][i])

		if j % number_of_angles == 0:
			# calculate the angle for the laser scan 
			angle = d["angle"]
			# plot on matplotlib 
			plt.plot(all_x, all_y, 'ro')
			plt.ylabel('value of intensity')
			plt.xlabel('number of angles')
			time = d["time"].replace(":", "_")
			
			# Save output
			im_path = image_output_path + ("%s.png" % time)
			plt_path = "C:\\PATH\\TO\\SAVE\\plt\\%s_plt.png" % time

			im.save(im_path)
			plt.savefig(plt_path)
			
			# clear image and plt figure
			plt.clf()
			all_x = []
			all_y = []
			im = Image.new(mode, size, color)
			x_count = 0
		else:
			x_count += 1

	if opt.scan_only == True:
		size = 64,64
		pixel_image_source_path = image_output_path
		pixel_output_path = "C:\\PATH\\TO\\SAVE"
		resize_image_in_folder(pixel_image_source_path, pixel_output_path, size)
