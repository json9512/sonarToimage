import os 
import numpy as np
from PIL import Image 

path = sorted([x for x in os.listdir("result/full_scan")], key=len)

# generate the list to store data
arr_list = [[] for i in range(485)]

# Store all the images as np.array according to the file number to the arr_list list
for f in path:
    for i in range(485):
        if int(f.split("_")[1].split(".")[0]) == i:
            arr = np.array(Image.open("result/full_scan/"+f))
            arr_list[i].append(arr)

final_img = []

# iterate through the final list (485)
for i, imgs in enumerate(arr_list):
    # append the images in the imgs list
    arr = np.vstack((imgs[0], imgs[1], imgs[2], imgs[3], imgs[4], imgs[5], imgs[6],  
                    imgs[7], imgs[8], imgs[9], imgs[10], imgs[11]))
    
    final_img.append(arr)

# Save the final image 
final_img = np.hstack(([final_img[i] for i in range(len(final_img))]))
print(final_img.shape)
Image.fromarray(np.uint8(final_img)).save("result/final_image/image2.png")


# change vstack -> hstack and vice versa on line 22, 28 if you want the picture to be horizontal/vertical


